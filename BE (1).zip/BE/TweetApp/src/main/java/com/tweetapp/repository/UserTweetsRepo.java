package com.tweetapp.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.tweetapp.model.UserTweets;

@Repository
public interface UserTweetsRepo extends JpaRepository<UserTweets, Long> {

	List<UserTweets> findByemail(String id);

}
