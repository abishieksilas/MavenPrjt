package com.tweetapp.service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.tweetapp.model.PasswordReset;
import com.tweetapp.model.UserRegistrationDto;
import com.tweetapp.model.UserTweets;
import com.tweetapp.repository.UserRegistrationRepo;
import com.tweetapp.repository.UserTweetsRepo;

@Service
public class TweetsService {
	
	@Autowired
	UserTweetsRepo userTweets;
	@Autowired
	UserRegistrationRepo userRegistration;
	
	public void postUserTweets(UserTweets data){
		
		    LocalDateTime myDateObj = LocalDateTime.now();
		    DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");
            String formattedDate = myDateObj.format(myFormatObj);
            data.setDate(formattedDate);
		    userTweets.save(data);
		}
	
   public void passwordReset(PasswordReset data){
	 
	   UserRegistrationDto dataInDatabase = userRegistration.findPasswordByEmail(data.getEmail());
	   String passwordInDatabase = dataInDatabase.getPassword();
	     System.out.println(userRegistration.updatePassword(data.getEmail(),data.getNewPassword());
	
	   
   }
	
}
