package com.tweetapp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.tweetapp.model.PasswordReset;
import com.tweetapp.model.UserRegistrationDto;
import com.tweetapp.model.UserTweets;
import com.tweetapp.repository.UserTweetsRepo;
import com.tweetapp.service.RegistrationService;
import com.tweetapp.service.TweetsService;

@RestController
public class Controller {

	@Autowired
	TweetsService tweetsService;

	@Autowired
	UserTweetsRepo userTweets;

	@Autowired
	RegistrationService registrationService;

	@PostMapping("/users/registration")
	public void userRegistration(@RequestBody UserRegistrationDto data) {
		
			registrationService.userRegistration(data);
		
	}

	@PostMapping("/user/tweets")
	public void postTweet(@RequestBody UserTweets data) {
		
			tweetsService.postUserTweets(data);
	}

	@GetMapping("/user/tweets")
	public List<UserTweets> findTweets() {
		return userTweets.findAll();
		} 
	}
	
	@GetMapping("/users")
	public List<String> findUsers() {

			return registrationService.findUsers();
		
	}

	@GetMapping("/user/tweet/{id}")
	public List<UserTweets> findTweetsById(@PathVariable("id") String id) {
		
			return userTweets.findByemail(id);
		


	}

	@PostMapping("/user/password/reset")
	public void updatePassword(@RequestBody PasswordReset data) {
		
		
			tweetsService.passwordReset(data);

		

	}

}
