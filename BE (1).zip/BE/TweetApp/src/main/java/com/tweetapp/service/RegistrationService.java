package com.tweetapp.service;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;


import org.springframework.stereotype.Service;

import com.tweetapp.model.UserRegistrationDto;
import com.tweetapp.repository.UserRegistrationRepo;



@Service
public class RegistrationService {


	@Autowired
	UserRegistrationRepo userRegistration;

	

	public void userRegistration(UserRegistrationDto data) {
 
		

		userRegistration.save(data);
	}

	@Override
	public UserRegistrationDto loadUserByUsername(String userName) throws UsernameNotFoundException {

		UserRegistrationDto user = userRegistration.findByEmail(userName);
		if (user == null)
		
		return user;

	}


	public UserRegistrationDto getDetailsByEmail(String userName) {
		UserRegistrationDto user = userRegistration.findByEmail(userName);
		
		return user;

	}

	
	public List<String> findUsers()  {
		List<Object[]> users = userRegistration.findUsers();
		List<String> res = new ArrayList<String>();
		for(Object[] obj : users){
		     String email = (String) obj[0];
		     String firstName = (String) obj[1];
		     JSONObject json = new JSONObject();
		     json.put("email", email);
		     json.put("firstName", firstName);
		     res.add(json.toString());
		     
		   }
		
		return res;
	}
	
}
