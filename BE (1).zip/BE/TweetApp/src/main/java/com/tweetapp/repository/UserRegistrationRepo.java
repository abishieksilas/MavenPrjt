package com.tweetapp.repository;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.tweetapp.model.UserRegistration;
import com.tweetapp.model.UserRegistrationDto;

@Repository
public interface UserRegistrationRepo extends JpaRepository<UserRegistrationDto,Long> {

	UserRegistrationDto findPasswordByEmail(String string);

	void save(UserRegistration user);

	UserRegistrationDto findByEmail(String userName);
    
	
	@Query("update UserRegistrationDto u set u.password = :password where u.email = :email")
	 int updatePassword(@Param("email") String email, @Param("password") String password);

	@Query("select u.email, u.firstName from UserRegistrationDto u")
	List<Object[]> findUsers();


}
