package com.tweetapp.service;

import org.springframework.security.core.userdetails.UserDetailsService;

import com.tweetapp.model.UserRegistrationDto;

public interface UsersService  extends UserDetailsService{

	UserRegistrationDto getDetailsByEmail(String userName); 

}
